module.exports = {
    MONGO_URI: '',
    REDIS_URI: ''
};