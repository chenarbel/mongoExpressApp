// required libraries
const mongoose = require('mongoose');
const Score = mongoose.model('Score');


module.exports = app => {
  app.get('/api/score', async (req, res) => {
    const scores = await Score.find().cache({ expire: 100 });
    
    res.json(scores);
  });
  
  app.post('/api/score', async (req, res) => {
    console.log(req.body);
    var email = req.body.email;
    var score = req.body.score;
    var date = req.body.date;
    
    if (!email || !score || !date) {
      return res.status(400).send('Missing email, score or date')
    }
    
    const score1 = new Score({
      email,
      score,
      date
    });
    
    try {
      await score1.save();
      res.send(score1);
    } catch (err) {
      res.status(400).send(err.message);
    }
  });
};
